create table `author` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `profile` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `author` VALUES (null, 'aa', 'bb');
INSERT INTO `author` VALUES (null, 'cc', 'ee');
INSERT INTO `author` VALUES (null, 'dd', 'ff');

create table `topic` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `content` text,
  `date` datetime NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  PRIMARY KEY(`id`)
);

INSERT INTO `topic` VALUES (null, 'MySQL', 'MySQL is...', '2020-01-01 02:03:04',1);
INSERT INTO `topic` VALUES (null, 'MySQL', 'MySQL is...', '2020-01-01 02:03:04',1);
INSERT INTO `topic` VALUES (null, 'MySQL', 'MySQL is...', '2020-01-01 02:03:04',2);
INSERT INTO `topic` VALUES (null, 'MySQL', 'MySQL is...', '2020-01-01 02:03:04',2);
INSERT INTO `topic` VALUES (null, 'MySQL', 'MySQL is...', '2020-01-01 02:03:04',3);
