package StackQueue;

import java.io.File;
import java.util.Scanner;

/*
 * Queue 구조는 FIFO(선입선출구조)로, 먼저 들어가는 자료가 먼저 빠져나오는 구조이다.
 * Queue를 만들어보고, 은행 창구 문제를 풀어보자.
 * 
 * 임의의 수의 고객들이 m초에 은행에 방문하여 n초간 은행 업무를 보는 입력값 (m,n)의 배열 Customer[]가 주어졌다.
 * 단 m은 오름차순 정렬되어 있으며, 창구는 하나라고 가정하자. 이 때 이 은행의 운영시간을 구하여라.
 * 예를 들어 입력값 배열이 다음과 같다고 하자: (0, 10), (5, 15), (20, 10)
 * 		0초에 첫 번째 고객이 와서 10초간 업무를 본다.
 * 		5초에 두 번째 고객이 왔지만 앞 고객이 창구에서 업무를 보고 있으므로 대기열에 선다.(큐에 추가)
 * 		10초에 첫 번째 고객이 업무를 마치고 두 번째 고객이 15초간 업무를 본다.(큐에서 삭제)
 * 		20초에 세 번째 고객이 왔지만 앞 고객이 창구에서 업무를 보고 있으므로 대기열에 선다.(큐에 추가)
 * 		25초에 두 번째 고객이 업무를 마치고 세 번째 고객이 10초간 업무를 본다.(큐에서 삭제)
 * 		35초에 세 번째 고객이 업무를 마친다. 이 은행은 35초간 운영되었다.
 * 
 * 풀이 힌트 (최적의 풀이법은 아님):
 *		컨셉: 실제 은행이 운영되듯이 코드를 짠다. 
 * 
 * 		for 반복문에서 현재시각(i)을 index 값으로 하고, 종료 조건은 생략한다. (int i=0; ;i++)
 * 
 * 		입력값 배열에도 index(j)를 마련하여, j에 해당하는 객체 array[j]의 방문시각(array[j].m)이 현재시각(i)과 일치할 때,
 * 		j가 가리키는 배열의 원소인 Customer 객체를 큐에 추가하고(Queue.push(array[j])), j 값을 1 올린다.
 * 
 * 		창구(Customer counter)가 비어 있고 큐에 Customer 객체가 들어 있다면, 큐에서 Customer 객체를 꺼내 창구에 할당한다(counter=Queue.pop()).
 * 		창구에 할당된 시각(t)을 저장하여(t=i), 창구에 할당된 시각(t)+고객의 업무 시간(customer.n)=고객의 업무 종료 시각(t+n)을 구한다.
 * 		i==t+n이면 창구를 비우거나(counter=null), 큐에 Customer 객체가 들어 있다면 새 Customer 객체를 꺼내 창구에 할당한다.
 * 
 * 		j가 입력값 배열을 전부 순회했고(j==array.length) 창구와 큐에 아무도 없다면(counter==null, queue.size==0)
 * 		이 순간 현재시각(i)이 결과값이다.
 * 
 * 입력값 예시: Customer[] = { (0, 10), (5, 15), (20, 10) }
 * 
 * 출력 예시:
 * 		입력받은 배열: Customer[].toString()
 * 		중간과정:	0초: 고객 (0, 10)이 창구에 입장했습니다.
 * 		 		5초: 고객 (5, 15)이 대기열에 입장했습니다.
 * 				10초: 고객 (0, 10)이 창구에서 퇴장했습니다. 고객 (5, 15)이 대기열에서 창구에 입장했습니다.
 * 				20초: 고객 (20, 10)이 대기열에 입장했습니다.
 * 				25초: 고객 (5, 15)이 창구에서 퇴장했습니다. 고객 (20, 10)이 대기열에서 창구에 입장했습니다.
 * 				35초: 고객 (20, 10)이 창구에서 퇴장했습니다.
 * 		최종 결과: 은행의 운영시간: 35초 
 */

public class Queue {
	//TODO: 큐 구조를 위한 변수 선언하기 (배열의 자료형은 Customer입니다)
	
	public Queue(){
		//TODO: 큐 구조의 적절한 생성자 정의하기
	}
	
	public void push(Customer c) {
		//TODO: 큐 구조의 push 메서드 정의하기
	}
	
	public int pop() {
		//TODO: 큐 구조의 pop 메서드 정의하기
		return 0;
	}
	
	//기타 메서드는 필요하다면 정의하세요(핵심은 push와 pop입니다)
	
	public static void bankCounterQueue(Customer[] array) {
		//TODO: Customer[] 입력값 배열을 받아 은행의 운영시간을 구한다.
		Queue q = new Queue();
	}
	
	public static void main(String[] args) throws Exception {
		for(int i=5; i<8; i++) {
			File file = new File("input" + i + ".txt");
			Scanner sc = new Scanner(file);
			int length = sc.nextInt();
			Customer[] array = new Customer[length];
			for(int j=0; j<length; j++) {
				if(sc.hasNextInt() == true)
					array[j] = new Customer(sc.nextInt(), sc.nextInt());
			}
			
			bankCounterQueue(array);
			
			sc.close();
		}
	}
}